-- Copyright (c) 2002-2010, Tim Sheard
-- OGI School of Science & Engineering, Oregon Health & Science University
-- Maseeh College of Engineering, Portland State University
-- Subject to conditions of distribution and use; see LICENSE.txt for details.
-- Fri May  7 10:18:58 Pacific Daylight Time 2010
-- Omega Interpreter: version 1.4.6

module Version where
version = "Omega Interpreter: version 1.4.6"
buildtime = "Fri May  7 10:18:58 Pacific Daylight Time 2010"
