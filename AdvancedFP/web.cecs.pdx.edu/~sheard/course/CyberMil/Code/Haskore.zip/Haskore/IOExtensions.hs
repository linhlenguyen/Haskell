module IOExtensions(
	module Hugs.IOExts,
    ) where

import Hugs.IOExts
