module Prop.Rewrite.Gen where

import Prop.Rewrite.Print 
import Prop         (Prop)
import Prop.Rewrite (Rewrite(..), RewritePool(..))
import Prop.Util    (RandM)
import Prop.Rewrite.Pool (emptyPool, fullPool)
import Control.Monad.Random
import Control.Monad(replicateM)

hugeNumber = 2^16
reasonablyBigNumber = 2^8

-- genRewrite: size   -> rewrite element pool -> random rewrite
genRewrite :: Int -> RewritePool -> RandM Rewrite 
genRewrite size pool 
  | size <= 2 = genPrim' pool
  | otherwise = do
        let g = [
                 genSizePred,
                 genAlgoFn,
                 genConverge,
                 genPrimSequence
                ]
        r <- getRandomR (0, length g - 1)
        s <- getRandomR (0, size)
        let k = size - s
        rw1 <- (selectAt r g) s pool

        if k <= 1 then return rw1 
                  else do rw2 <- fmap (:[]) (genRewrite k pool)
                          return $ Sequence $ rw1 : rw2

genRewrite' :: Int -> RewritePool -> IO Rewrite
genRewrite' size pool = evalRandIO $ genRewrite size pool

genPrim' pool = do
        let eqs = eqFns pool
            eqpfs = eqPredFns pool
            ps = primFns pool
            g = replicate (length eqpfs) (genEqPred eqs eqpfs) ++  
                 replicate (length ps) (genPrim ps)
        r <- getRandomR (0, length g - 1)
        selectAt r g



genPrimSequence size pool = fmap Sequence $ replicateM size (genPrim' pool)


genPred size pool = do
    let preds = predFns pool
    if null preds 
        then genRewrite size pool 
        else do
            r <- getRandomR (0, length preds - 1)
            let (p, nm) = selectAt r preds
            rw <- genRewrite (size - 1) pool
            return $ Pred p rw nm

genSizePred size pool = do
    let sfs = sizeFns pool
    if null sfs 
        then genRewrite size pool 
        else do
            r <- getRandomR (0, length sfs - 1)
            hi <- getRandomR (0, hugeNumber)
            let (p, nm) = selectAt r sfs
            rw <- genRewrite (size - 1) pool
            return $ SizePred p hi rw nm

genEqPred eqs eqpfs = do
            r <- getRandomR (0, length eqs - 1)
            s <- getRandomR (0, length eqpfs - 1)
            let (p, pnm) = selectAt r eqs
            let (f, fnm) = selectAt s eqpfs
            return $ EqPred p f pnm fnm


genAlgoFn size pool = do
    let algos = algoFns pool
    if null algos
        then genRewrite size pool 
        else do
            rw <- genRewrite (size - 1) pool
            r <- getRandomR (0, length algos - 1)
            let (alg, nm) = selectAt r algos
            return $ Algo alg rw nm

genConverge size pool = do
    rw <- genRewrite (size - 1) pool 
    let ps = convergePredFns pool
    pr <- getRandomR (0, length ps - 1)
    h <- getRandomR (0, reasonablyBigNumber)
    let (p, s) = selectAt pr ps
    return $ Converge p h rw s

genPrim ps = do
    r <- getRandomR (0, max 0 (length ps - 1))
    let (f, nm) = selectAt r ps
    return (Prim f nm)

selectAt :: Int -> [a] -> a
selectAt _ []                 = error "Selecting from empty list."
selectAt _ [x]                = x
selectAt n (x:zs) | n <= 0    = x
selectAt n (x:y:zs)           = selectAt (n - 1) (y:zs)


