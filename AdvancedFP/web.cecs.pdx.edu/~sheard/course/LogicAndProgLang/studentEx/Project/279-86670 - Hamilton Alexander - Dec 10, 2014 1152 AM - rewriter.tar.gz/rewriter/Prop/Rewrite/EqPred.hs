module Prop.Rewrite.EqPred where

import Prop(Prop(..))

doubleUnDistribute :: (Prop -> Prop -> Bool) -> Prop -> Prop
doubleUnDistribute eq p = case p of
    ((p `Or` r) `And` (p' `Or` s)) `And` ((q `Or` r') `And` (q' `Or` s'))
      | eq p p' && eq q q' && eq r r' && eq s s' -> (p `And` q) `Or` (r `And` s)
    ((p `And` r) `Or` (p' `And` s)) `Or` ((q `And` r') `Or` (q' `And` s'))
      | eq p p' && eq q q' && eq r r' && eq s s' -> (p `Or` q) `And` (r `Or` s)
    p -> p

unDistribute :: (Prop -> Prop -> Bool) -> Prop -> Prop
unDistribute eq p = case p of
    And (Or p q)  (Or p' r)              | eq p p' -> Or p (And q r)
    Or  (And p q) (And p' r)             | eq p p' -> And p (Or q r)
    Implies (Implies p q) (Implies q' r) | eq q q' -> Implies p (Implies q r)
    p                                              -> p

elimRedundant :: (Prop -> Prop -> Bool) -> Prop -> Prop
elimRedundant eq p = case p of
    And x y           | eq x y -> x
    Or  x y           | eq x y -> x
    And x w@(And y z) | eq x y -> w
    And w@(And y z) x | eq x y -> w
    Or x w@(Or y z)   | eq x y -> w
    Or w@(And y z) x  | eq x y -> w
    Implies p q       | eq p q -> Top
    p                          -> p 

elimConjugate :: (Prop -> Prop -> Bool) -> Prop -> Prop
elimConjugate eq p = case p of
    And p q     | eq p (Not q) -> Bottom
    Or  p q     | eq p (Not q) -> Top
    p                          -> p

introNegate :: (Prop -> Prop -> Bool) -> Prop -> Prop
introNegate eq p = case p of
    And (Implies p q) (Implies p' q') | eq p p' && eq q (Not q') -> Not p
    p -> p
