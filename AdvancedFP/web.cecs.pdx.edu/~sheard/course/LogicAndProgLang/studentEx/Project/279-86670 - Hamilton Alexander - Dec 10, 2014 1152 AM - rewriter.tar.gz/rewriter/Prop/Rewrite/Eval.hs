{-# Language BangPatterns #-}
module Prop.Rewrite.Eval where
import Prop                 
import Prop.Eval            (propSize)
import Prop.Util            (RandM, RandProp, roulette, timeOutPure)
import Prop.Rewrite         (Rewrite(..))
import Prop.Rewrite.Algo    (bottomUp, topDown, converge)
import Control.Monad.Random (getRandomR, evalRandIO)

-- Evaluation methods for Rewrite

-- Evaluate every part of the rewriting strategy, no matter how long it takes
evalCompletely :: Rewrite -> Prop -> Prop
evalCompletely !rewrite !p = case rewrite of
    Prim !f _            -> f p
    Pred !f !rw _         -> if f p then evalCompletely rw p else p
    SizePred !f !h !r _ -> let s = f p in if (s < h) then evalCompletely r p else p
    Algo !algo !rw _      -> algo (evalCompletely rw) p
    Converge !f !i !rw _   -> converge (evalCompletely rw) f i p
    Sequence []         -> p
    Sequence (!x:xs)     -> evalCompletely (Sequence xs) (evalCompletely x p)    
    EqPred !pr !f _ _      -> f pr p

evalTimeOut :: Double -> Rewrite -> Prop -> IO (Double, Maybe Prop)
evalTimeOut seconds rw p = timeOutPure seconds (evalCompletely rw p) 

