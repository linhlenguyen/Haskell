module Prop.Print where
import Prop                      (Prop(..))
import Text.PrettyPrint.HughesPJ (cat, parens, punctuate, render, text, (<>))
import Data.Char                 (chr, ord, toUpper, toLower)

inRadix r 0 = [0]
inRadix r n = reverse $ inRadix' r n where
  inRadix' _ 0 = []
  inRadix' r n = let m = n `mod` r 
                     k = n `div` r 
                  in m : inRadix' r k

toAlpha n        = chr (ord 'A' + n)

titleCase []     = []
titleCase (x:xs) = toUpper x : map toLower xs

ppLetter n
  | n < 0       = text $ 'p':show (-n)
  | otherwise   = text $ titleCase $ map toAlpha $ inRadix 26 n

ppParens n p    = case p of
    Top                         -> ppProp Top
    Bottom                      -> ppProp Bottom
    Letter n                    -> ppProp (Letter n)
    Not p                       -> ppProp (Not p)
    term 
      | n /= precedence term     -> parens (ppProp term)
      | otherwise                -> ppProp term
  where 
    precedence term = case term of
        Not _       -> 5
        And _ _     -> 4
        Or  _ _     -> 3
        Implies _ _ -> 2
        _           -> 6
        

ppProp p        = case p of
    Letter n    -> ppLetter n
    Top         -> text " ⊤ "
    Bottom      -> text " ⊥ "
    Not p       -> text "¬" <> ppParens 1 p
    And p q     -> ppParens 4 p <> text " ∧ " <> ppParens 4 q 
    Or  p q     -> ppParens 3 p <> text " ∨ " <> ppParens 3 q
    Implies p q -> ppParens 3 p <> text " ⇒ " <> ppParens 2 q
  where 

printProp = render . ppProp
