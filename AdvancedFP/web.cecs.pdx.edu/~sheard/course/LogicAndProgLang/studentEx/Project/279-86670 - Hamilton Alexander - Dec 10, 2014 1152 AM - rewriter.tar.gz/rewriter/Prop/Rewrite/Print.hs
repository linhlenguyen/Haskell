module Prop.Rewrite.Print where

import Prop.Rewrite(Rewrite(..))
import Text.PrettyPrint.HughesPJ((<>), (<+>), ($$), ($+$), 
                                 hang, lbrace, rbrace, nest,
                                 render, parens, sep, text, int, empty)

ppRewrite rw = case rw of
    Prim _ s -> text "rewrite" <> parens (text s)
    Pred _ rw s -> (text "if" <+> parens (text s) <+> lbrace) 
                    $+$ nest 4 (ppRewrite rw) $+$ rbrace

    SizePred _ hi rw s -> (text "if" <+> text s <+> text "is less than"
                               <+> int hi <+> lbrace)
                              $+$ nest 4 (ppRewrite rw) $+$ rbrace
    Sequence xs -> sep $ map ppRewrite xs
    EqPred _ _ p f -> (text "rewrite" <> parens (text f) <+> text "using" <+> parens (text p))
    Converge _ i rw s -> (text "until convergence" <+> (text "or at most" 
                                                        <+> int i <+> text "iterations")
                                                   <+> lbrace) $+$ nest 4 (ppRewrite rw) $+$ rbrace
    Algo _ rw nm -> (text "apply" <+> text nm <+> lbrace) 
                    $+$ nest 4 (ppRewrite rw) $+$ rbrace

instance Show Rewrite where
    show = render . ppRewrite
