module Prop.Discrim where
import Prop                      (Prop(..))
import Data.Set                  (Set)
import qualified Data.Set as Set (fromList, insert, map, singleton, toList)

data Discrim a = Alpha a a
               | Beta  a a
               | Lit   a

discrim :: Prop -> Discrim Prop
discrim Top                     = Lit   Top
discrim Bottom                  = Lit   Bottom
discrim (Letter l)              = Lit   (Letter l)
discrim (Not Top)               = Lit   Bottom
discrim (Not Bottom)            = Lit   Top
discrim (Not (Letter l))        = Lit   (Not (Letter l))
discrim (Or  x y)               = Beta  x y
discrim (Implies p q)           = Beta  (Not p) q
discrim (Not (And x y))         = Beta  (Not x) (Not y)
discrim (And x y)               = Alpha x y
discrim (Not (Or x y))          = Alpha (Not x) (Not y)
discrim (Not (Implies p q))     = Alpha (Not q) p
discrim (Not (Not x))           = discrim x


processClauses :: [Prop] -> [[Prop]]
processClauses [] = [[]]
processClauses (p:ps) =
    case discrim p of
         Lit x     -> map (x:) (processClauses ps)
         Alpha x y -> processClauses (x:ps) ++ processClauses (y:ps)
         Beta x y  -> processClauses (x:y:ps)

cnf :: Prop -> Prop
cnf p = implicitCnf $ processClauses [p]

implicitCnf :: [[Prop]] -> Prop
implicitCnf = foldr And Top . map (foldr Or Bottom)

simpleCnf :: Prop -> Prop
simpleCnf x = implicitCnf $ simpleCnfL $ processClauses [x]

simpleCnfL [] = []
simpleCnfL (x:xs)
      | elem Top x = simpleCnfL xs
      | conjugatePair x = simpleCnfL xs
      | subsumes xs x = simpleCnfL xs
      | otherwise = x : simpleCnfL xs

conjugatePair [] = False
conjugatePair [x] = False
conjugatePair (Letter x : xs) = elem (Not (Letter x)) xs || conjugatePair xs
conjugatePair (Not x : xs) = elem x xs || conjugatePair xs
conjugatePair (x:xs) = conjugatePair xs

subsumes [] x = False
subsumes (ys : yss) xs = all (`elem` xs) ys || subsumes yss xs
