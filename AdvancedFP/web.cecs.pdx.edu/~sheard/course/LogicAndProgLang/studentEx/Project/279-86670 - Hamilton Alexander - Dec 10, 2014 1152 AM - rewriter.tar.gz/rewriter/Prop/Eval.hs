module Prop.Eval where
import Prop                      (Prop(..))
import Prop.Util                 (doubleton)
import Data.Set                  (Set)
import qualified Data.Set as Set (deleteFindMin, empty, filter, fold, fromList, 
                                  insert, map, member, null, size, union)

-- Valuation
value :: (Int -> Bool) -> Prop -> Bool
value _  Top            = True
value _  Bottom         = False
value vf (Not x)        = not (value vf x)
value vf (And x y)      = value vf x && value vf y
value vf (Or  x y)      = value vf x || value vf y
value vf (Implies p q)  = if value vf p then value vf q else True
value vf (Letter l)     = vf l

value' :: Set Int -> Prop -> Bool
value' vs = value (\l -> Set.member l vs)


-- Find the variables used in a proposition.
addvars :: Prop -> Set Int -> Set Int
addvars p xs 
  | p == Bottom || p == Top  = Set.empty
addvars (Letter y) xs        = Set.insert y xs
addvars (Not p) xs           = addvars p xs
addvars p xs                 = Set.fold Set.union xs $ Set.map (flip addvars xs)
                             $ case p of 
                                    And x y -> doubleton x y
                                    Or  x y -> doubleton x y
                                    Implies x y -> doubleton x y

vars :: Prop -> Set Int
vars = flip addvars Set.empty

varCount = Set.size . vars
assignCount :: Prop -> Int
assignCount = (2^) . varCount 

-- Find the set of assignments, 
-- i.e. the power set of the variable set.
assigns :: Set Int -> Set (Set Int)
assigns xs 
  | Set.null xs = Set.empty
  | Set.size xs == 1 = Set.fromList [xs, Set.empty]
  | otherwise = let (y, ys) = Set.deleteFindMin xs
                    assume p = (if p then Set.map (Set.insert y) else id) $ assigns ys
                 in Set.union (assume True) (assume False)

-- Find the set of assignments directly from a Prop.
assigns' :: Prop -> Set (Set Int)
assigns' = assigns . vars

-- Compute the True valuations of a proposition under a particular assignment. 
valuations :: Prop -> Set Int -> Set (Set Int) 
valuations p vs = Set.filter (flip value' p) (assigns vs)

-- Compute the lines in the truth table that are True.
truthtab :: Prop -> Set (Set Int)
truthtab p = valuations p (vars p)

-- Compute whether the function is a tautology and whether it is absurd.
satInfo :: Prop -> (Bool, Bool)
satInfo p = (as == tt, Set.null tt) where
    as = assigns (vars p)
    tt = Set.filter (flip value' p) as

-- Determine if a formula is a tautology by seeing if its negation is absurd.
tautology :: Prop -> Bool
tautology p = absurd (Not p)

-- Determine if a formula is absurd by seeing if no assignments are True.
absurd :: Prop -> Bool
absurd p = Set.null (truthtab p)

-- Determine if a formula is satisfiable by seeing if 
satisfiable :: Prop -> Bool
satisfiable p = not (absurd p)

-- Determine if two formulae are equal by bidirectional implication.
equal :: Prop -> Prop -> Bool
equal p q = tautology $ (p `Implies` q) `And` (q `Implies` p)

-- Determine if two formulae are equal by directly comparing the truth tables.
equal' :: Prop -> Prop -> Bool
equal' p q = let vs  = Set.union (vars p) (vars q) 
              in valuations p vs == valuations q vs

-- Measure the size of a proposition.
-- This measurement just counts the (non-parenthesis) symbols involved in a proposition,
-- treating Letters and their direct conjugates as 1.
propSize :: Prop -> Int
propSize p = case p of
    Letter i       -> 1
    Not (Letter i) -> 1
    Top            -> 1
    Bottom         -> 1
    Not p          -> 1 + propSize p
    And p q        -> 1 + propSize p + propSize q
    Or  p q        -> 1 + propSize p + propSize q 
    Implies p q    -> 1 + propSize p + propSize q


