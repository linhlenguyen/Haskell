module Prop.Test where
import Prop                      (Prop)
import Prop.Print                (printProp)
import Prop.Eval                 (propSize, equal, vars, tautology, satisfiable, absurd, satInfo)
import Prop.Rewrite.Eval         (evalCompletely, evalTimeOut)
import Prop.Rewrite.Composite    (simplifierTedCooper)
import Prop.Discrim              (cnf)
import Prop.Gen                  (genProp')
import Prop.Util                 (timeOut, timeOutPure)
import Control.Monad             (replicateM)
import Control.Monad.Random      (evalRandIO)
import Data.Maybe                (isJust)
import qualified Data.Set as Set (size)

-- Generate a proposition and output some information about it.
genTest :: [Double] -> Int -> Int -> IO ()
genTest rs hi size = do
    p <- genProp' rs hi size
    let s = propSize p
    putStrLn ("Size:        " ++ show (propSize p))
    if s < 100 
        then do
            putStrLn ("Formula:     " ++ printProp p)
        else putStrLn "Formula is very large..."
    putStrLn ("Satisfiable: " ++ show (satisfiable p))
    putStrLn ("Absurd:      " ++ show (absurd p))
    putStrLn ("Satprops:    " ++ show (satInfo p))

genMany :: [Double] -> Int -> Int -> Int -> IO [Prop]
genMany rs hi size count = replicateM count $ genProp' rs hi size

-- Get statistics for various sizes
genAvgs :: [Double] -> Int -> Int -> Int -> IO ()
genAvgs rs hi size count = do
    xs <- genMany rs hi size count
    let c = (fromIntegral count) :: Double
        --pr p = fromIntegral (length $ filter p xs) / c
       -- avgVarCount =  (sum (map (Set.size . vars) xs)) / c
--        avgTautRate = pr tautology
  --      avgSatRate  = pr satisfiable
    --    avgAbsRate  = pr absurd
       -- avgSize     = (sum (map propSize xs)) / c
      --  avgCnfRate  = pr (\x -> equal (cnf x) x)
    (avgTedRate, avgTedTime)  <- do (t,ps) <- fmap unzip $ mapM (evalTimeOut 5 simplifierTedCooper) xs
                                    return $ (fromIntegral (length $ filter isJust ps) / c, sum (filter (/=0) t) / c)
    --putStrLn ("Avg. var. count:    " ++ show avgVarCount)
    --putStrLn ("Avg. taut. rate:    " ++ show avgTautRate)
    --putStrLn ("Avg. sat.  rate:    " ++ show avgSatRate)
    --putStrLn ("Avg. absurd rate:   " ++ show avgAbsRate)
    --putStrLn ("Rate of correct CNF:" ++ show avgCnfRate)
    putStrLn ("Rate of finished transform:" ++ show avgTedRate)
    putStrLn ("Avg. transform time: " ++ show avgTedTime)
    -- putStrLn ("Avg. size:          " ++ show avgSize)


-- Some example ratios of connectives.
rs0 = [1, 1, 1, 1 :: Double]
rs1 = [3, 5, 2, 2 :: Double] 
rs2 = [2, 3, 3, 5 :: Double]
nand = [1, 1, 0, 0 :: Double]
nor  = [1, 0, 1, 0 :: Double]
impliesNeg = [1, 0, 0, 1 :: Double]
impliesOnly = [0, 0, 0, 1 :: Double]
noImplies = [1, 1, 1, 0 :: Double]
