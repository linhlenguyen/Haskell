module Prop.Rewrite.GA.Selection where

import Prop.Rewrite.GA
import Data.List
import Data.Ord
import Control.Arrow

softmax :: SelectionFn
softmax rs = let ls = map (first exp) rs
                 s = sum (map fst ls)
              in map (first (/s)) ls

rankProportionate :: SelectionFn
rankProportionate xs = let sxs = map snd $ sortBy (comparing fst) xs 
                        in zip (map (1/) [1..]) sxs

    
fitnessProportionate :: SelectionFn
fitnessProportionate = id
