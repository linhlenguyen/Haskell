module Prop.Rewrite.GA.Mutation where

import Prop.Rewrite.GA
import Prop.Rewrite
import Prop.Rewrite.Gen
import Control.Monad.Random
import Prop.Util

-- Possibly replace a part of the rewrite with a random rewrite of about the same size
spliceRandomRewrite :: RewritePool -> MutationFn
spliceRandomRewrite pool rate rw = do
    r <- getRandomR (0, 1)
    o <- getRandomR (-3, 3)
    if r > rate / fromIntegral (rewriteSize rw)
        then spliceSubtree o pool rate rw
        else spliceRoot o pool rate rw
       
spliceRoot o pool rate rw = case rw of
    Prim _ _ -> genRewrite (o + 1) pool
    EqPred _ _ _ _ -> genRewrite (o + 1) pool
    Pred _ rw _ -> genRewrite (rewriteSize rw + o + 1) pool
    Sequence rws -> genRewrite (sum $ map rewriteSize rws) pool
    Algo _ rw _ -> genRewrite (rewriteSize rw + o + 1) pool
    Converge _ _ rw _ -> genRewrite (rewriteSize rw + o + 1) pool
    SizePred _ _ rw _ -> genRewrite (rewriteSize rw + o + 1) pool


spliceSubtree o pool rate rw = case rw of
    Pred p rw s -> fmap (\r -> Pred p r s) $ spliceRandomRewrite pool (rate / 2) rw
    SizePred p i rw s -> fmap (\r -> SizePred p i r s) $ spliceRandomRewrite pool (rate / 2) rw
    Algo a rw s -> fmap (\r -> Algo a r s) $ spliceRandomRewrite pool (rate / 2) rw
    Converge p i rw s -> fmap (\r -> Converge p i r s) $ spliceRandomRewrite pool (rate / 2) rw
    Sequence rws -> fmap Sequence 
        $ mapM (\r -> spliceRandomRewrite pool (rate / fromIntegral (length rws)) r) rws
    rw -> spliceRandomRewrite pool (rate / 2) rw

-- Alter numerical values in SizePred and Converge
alterRewriteParams rate rw = case rw of
    SizePred f i rw s -> do
        i' <- newSizePred i rate
        return $ SizePred f i' rw s
    Converge f i rw s ->  do
        i' <- newSizePred i rate
        return $ Converge f i' rw s
    rw -> return rw

newSizePred :: Int -> Double -> RandM Int
newSizePred i rate = fmap (round . (fromIntegral i *)) $ getRandomR (1-rate, 1+rate)

-- Randomly splice or alter
spliceAndAlter :: RewritePool -> MutationFn
spliceAndAlter pool rate rw = do
    b <- getRandomR (False, False) -- spliceRandomRewrite was slow
    if b then spliceRandomRewrite pool rate rw
         else alterRewriteParams rate rw
