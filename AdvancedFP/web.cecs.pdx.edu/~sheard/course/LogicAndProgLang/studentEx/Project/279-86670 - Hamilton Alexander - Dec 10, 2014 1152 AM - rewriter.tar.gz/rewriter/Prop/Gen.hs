module Prop.Gen where
import Prop                      (Prop(..))
import Prop.Util                 (RandState, roulette) 
import Control.Monad.Random      (getRandomR, newStdGen, evalRandT)
import Control.Monad.State.Strict(evalState, get, put, lift)
import Data.Set                  (Set)
import qualified Data.Set as Set (empty, insert, singleton)

-------------------------------------------------------------------------------
-- Random Generation of Prop Instances



genProp :: [Double] -> Int -> Int -> RandState Prop
genProp rs hi size
  | 0 > hi = error "Invalid variable name range - provide upper bound > 0."
  | otherwise = do
      return Top
      if size <= 1
       then genLetter hi
       else genConnective rs hi size
    
-- Generate a random letter. 
genLetter :: Int -> RandState Prop
genLetter hi = do
    start <- lift get
    l   <- getRandomR (0, start)
    if l == start then put (min (start + 1) (hi - 1)) else return ()
    return $ Letter l

-- Generate a connective.
-- Subdivide size and recurse to make subterms.
genConnective :: [Double] -> Int -> Int -> RandState Prop
genConnective rs hi size = do 
    r <- getRandomR (0, sum rs :: Double)
    roulette r (zip rs [fmap Not (genProp rs hi (size - 1)),
                        genConnectivePair And,
                        genConnectivePair Or,
                        genConnectivePair Implies])
        where genConnectivePair c = do 
                           k <- getRandomR (0, size - 1)
                           p <- genProp rs hi k
                           q <- genProp rs hi (size - k - 2)
                           return (c p q)


genProp' :: [Double] -> Int -> Int -> IO Prop
genProp' rs hi size
  | size < 1 = error "Invalid proposition size - must be 1 or greater."
  | otherwise = do
      g <- newStdGen
      return $ evalState (evalRandT (genProp rs hi size) g) 0
