{-# Language BangPatterns #-}
module Prop.Rewrite.Algo        (converge, bottomUp, topDown, 
                                pickLargestSubtree, pickSmallestSubtree,
                                pickMostVars, pickLeastVars,
                                findLargestComponent, findMostVarComponent) where

import Prop                      (Prop(..))
import Prop.Eval                 (propSize, varCount)
import Data.Function             (on)
import qualified Data.Set as Set (fromList, toList)

-- Possibly forced-finite convergence
converge :: (Prop -> Prop) -> (Prop -> Prop -> Bool) -> Int -> Prop -> Prop
converge rw f 0 p = rw p
converge rw f m p = let p' = rw p in if f p p' 
       then p else converge rw f (m - 1) p'

-- General rewriting algorithms
bottomUp :: (Prop -> Prop) -> Prop -> Prop
bottomUp !rw = rw . pushTransform (bottomUp rw)

topDown :: (Prop -> Prop) -> Prop -> Prop
topDown !rw = pushTransform (topDown rw) . rw

pickLargestSubtree :: (Prop -> Prop) -> Prop -> Prop
pickLargestSubtree = pickSubtreeBy ((>) `on` propSize)

pickSmallestSubtree :: (Prop -> Prop) -> Prop -> Prop
pickSmallestSubtree = pickSubtreeBy ((<) `on` propSize)

pickLeastVars :: (Prop -> Prop) -> Prop -> Prop
pickLeastVars = pickSubtreeBy ((<) `on` varCount)

pickMostVars :: (Prop -> Prop) -> Prop -> Prop
pickMostVars = pickSubtreeBy ((>) `on` varCount)

findLargestComponent :: (Prop -> Prop) -> Prop -> Prop
findLargestComponent = pathTraversal ((>) `on` propSize)

findMostVarComponent :: (Prop -> Prop) -> Prop -> Prop
findMostVarComponent = pathTraversal ((>) `on` varCount)

-- Building blocks
pushTransform :: (Prop -> Prop) -> Prop -> Prop 
pushTransform !rw !p  = case p of
        And     p q -> And (rw p) (rw q)
        Or      p q -> Or  (rw p) (rw q)
        Implies p q -> Implies (rw p) (rw q)
        Not     p   -> Not (rw p)
        x           -> rw x

pickSubtreeBy :: (Prop -> Prop -> Bool) -> (Prop -> Prop) -> Prop -> Prop
pickSubtreeBy f rw p = case p of
         And p q -> f' And p q 
         Or  p q -> f' Or p q
         Implies p q -> f' Implies p q
         other -> rw other
  where f' c p q = if f p q then c (rw p) q else c p (rw q)

pathTraversal :: (Prop -> Prop -> Bool) -> (Prop -> Prop) -> Prop -> Prop
pathTraversal f rw = rw . pushTransform (pickSubtreeBy f $ pathTraversal f rw)


