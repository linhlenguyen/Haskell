{-# Language BangPatterns #-}
module Prop.Rewrite.Prim where


import Prop                      (Prop(..))
import Prop.Eval                 (satInfo, tautology)
-- Primitive functions

-- Replace propositions with definitely smaller propositions.
shrinkIdentities :: Prop -> Prop
shrinkIdentities = idAnd . idOr . idNot . idImplies

idAnd :: Prop -> Prop
idAnd p = case p of
    And x Top               -> x
    And Top x               -> x
    And Bottom x            -> Bottom
    And x Bottom            -> Bottom
    p                       -> p

idOr :: Prop -> Prop
idOr p = case p of
    Or Top x                -> Top
    Or  x Top               -> Top
    Or Bottom x             -> x
    Or x Bottom             -> x
    p                       -> p

idImplies :: Prop -> Prop
idImplies !p = case p of
    Implies Top !x           -> x
    Implies !x Top           -> x
    Implies Bottom !x        -> Top
    Implies !x Bottom        -> Not x
    !p                       -> p

idNot :: Prop -> Prop
idNot p = case p of
    Not Top                 -> Bottom
    Not Bottom              -> Top
    Not (Not p)             -> p
    p                       -> p


elimTautology :: Prop -> Prop
elimTautology p 
  | taut = Top
  | unsat = Bottom
  | otherwise = p
    where (taut, unsat) = satInfo p

deMorganPush :: Prop -> Prop
deMorganPush p = case p of
    Not (And p q) -> Or  (Not p) (Not q)
    Not (Or  p q) -> And (Not p) (Not q)
    p             -> p

deMorganPull :: Prop -> Prop
deMorganPull p = case p of
    Or (Not p) (Not q) -> Not (And p q)
    And (Not p) (Not q) -> Not (Or p q)
    p -> p

elimImplies :: Prop -> Prop
elimImplies !p = case p of
    And !x !y -> And (elimImplies x) (elimImplies y)
    Or !x !y -> Or (elimImplies x) (elimImplies y)
    Implies !x !y -> elimImplies $! (idImplies $! (Implies x y))
    Not !x -> Not (elimImplies x)
    !p -> p

nnf :: Prop -> Prop
nnf p = case p of
    And x y -> And (nnf x) (nnf y)
    Or x y  -> And (nnf x) (nnf y)
    Implies x y -> nnf (Or (Not x) y)
    Not x -> idNot $ Not (nnf x)
    p -> p

distribute :: Prop -> Prop
distribute p = case p of
    And p (Or q r)          -> Or  (And p q) (And p r)
    And (Or q r) p          -> Or  (And p q) (And p r)
    Or p (And q r)          -> And (Or p q)  (Or p r)
    Or (And q r) p          -> And (Or p q)  (Or p r)
    Implies p (Implies q r) -> Implies (Implies p q) (Implies q r)
    p                       -> p

doubleDistribute :: Prop -> Prop
doubleDistribute p = case p of
    (p `And` q) `Or` (r `And` s) -> 
        ((p `Or` r) `And` (p `Or` s)) `And` ((q `Or` r) `And` (q `Or` s))
    (p `Or` q) `And` (r `Or` s) -> 
        ((p `And` r) `Or` (p `And` s)) `Or` ((q `And` r) `Or` (q `And` s))
    p -> p


assocLeft :: Prop -> Prop
assocLeft p = case p of
    And p (And q r) -> And (And p q) r
    Or  p (Or  q r) -> Or  (Or p q) r
    p -> p

assocRight :: Prop -> Prop
assocRight p = case p of
    And (And p q) r -> And p (And q r)
    Or  (Or p q)  r -> Or  p (Or q r)
    p -> p

commute :: Prop -> Prop
commute p = case p of
    And p q -> And q p
    Or  p q -> Or q p
    Implies p (Implies q r) -> Implies q (Implies p r)
    p -> p

transpose :: Prop -> Prop
transpose p = case p of
    Implies (Not p) (Not q) -> Implies q p
    Implies p q -> Implies (Not q) (Not p)
    p -> p

materialize :: Prop -> Prop
materialize p = case p of
    Implies p q -> Or (Not p) q
    p -> p

dematerialize :: Prop -> Prop
dematerialize p = case p of
    Or (Not p) q -> Implies p q
    p -> p

exportation :: Prop -> Prop
exportation p = case p of
    Implies (And p q) r -> Implies p (Implies q r)
    p -> p

importation :: Prop -> Prop
importation p = case p of
    Implies p (Implies q r) -> Implies (And p q) r
    p -> p


implicationTaut :: Prop -> Prop
implicationTaut p = case p of
    And p q | tautology (Implies p q) -> p
            | tautology (Implies q p) ->  q
    Implies p q | tautology q         -> p
    p -> p

elimSimple :: Prop -> Prop
elimSimple p = case p of
    And (Letter x) (Letter y) | x == y                   -> Letter x
    And p q                   | p == Not q || q == Not p -> Bottom
    Or  (Letter x) (Letter y) | x == y                   -> Letter x
    Or p q                    | p == Not q || q == Not p -> Top
    Implies (Letter x) (Letter y) | x == y               -> Top
    p -> p  

