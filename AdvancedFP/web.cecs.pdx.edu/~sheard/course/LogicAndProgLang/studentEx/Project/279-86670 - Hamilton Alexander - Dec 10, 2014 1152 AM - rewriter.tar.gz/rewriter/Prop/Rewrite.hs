{-# Language DeriveGeneric #-}

module Prop.Rewrite where

import Prop (Prop(..))
import Control.DeepSeq  (NFData(rnf))
import Control.DeepSeq.Generics (genericRnf)
import GHC.Generics     (Generic)

data Rewrite = Prim      !(Prop -> Prop) !String
             | Pred      !(Prop -> Bool) !Rewrite !String
             | SizePred  !(Prop -> Int) !Int !Rewrite !String
             | EqPred    !(Prop -> Prop -> Bool) !((Prop -> Prop -> Bool) -> Prop -> Prop) !String !String
             | Algo      !((Prop -> Prop) -> Prop -> Prop) !Rewrite !String
             | Converge  !(Prop -> Prop -> Bool) !Int !Rewrite !String
             | Sequence  ![Rewrite]
             deriving (Generic)

instance NFData Rewrite where rnf = genericRnf

type LList a = [(a, String)]

data RewritePool    = RewritePool {
    primFns         :: LList (Prop -> Prop),
    predFns         :: LList (Prop -> Bool),
    sizeFns         :: LList (Prop -> Int),
    eqFns           :: LList (Prop -> Prop -> Bool),
    eqPredFns       :: LList ((Prop -> Prop -> Bool) -> Prop -> Prop),
    convergePredFns :: LList (Prop -> Prop -> Bool),
    algoFns         :: LList ((Prop -> Prop) -> Prop -> Prop),
    seedRewrites    :: LList (Rewrite)
}



rewriteSize :: Rewrite -> Int
rewriteSize rw = case rw of
    Prim _ _ -> 1
    Pred _ rw _ -> 1 + rewriteSize rw
    SizePred _ _ rw _ -> 1 + rewriteSize rw
    EqPred _ _ _ _ -> 2
    Algo _ rw _ -> 1 + rewriteSize rw
    Converge _ _ rw _ -> 1 + rewriteSize rw
    Sequence rs -> sum (map rewriteSize rs)
