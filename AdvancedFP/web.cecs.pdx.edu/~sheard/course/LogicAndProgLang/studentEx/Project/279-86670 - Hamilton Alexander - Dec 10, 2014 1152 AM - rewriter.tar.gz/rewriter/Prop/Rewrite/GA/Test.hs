module Main where

import Prop.Rewrite.GA
import Prop.Rewrite.GA.Eval
import Prop.Rewrite.GA.Fitness
import Prop.Rewrite.GA.Selection
import Prop.Rewrite.GA.Mutation
import Prop.Rewrite.Pool
import Prop.Rewrite.Gen
import Control.Monad
import Control.Monad.Random

timeout = 2.0
fitness = timeAndSize timeout
selection = rankProportionate
mutation = spliceAndAlter fullPool 
crossover = undefined
ga_fns = GARW fitness selection mutation crossover

ga_instance = GAParams timeout 0 0.1 [1,1,1,1] (5,8) (10, 20)

eval = evalGA ga_fns ga_instance 100

start = replicateM 100 $ genRewrite 10 fullPool 

go = do
    s <- evalRandIO start
    eval s

main = go
