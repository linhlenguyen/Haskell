{-# Language BangPatterns #-}

module Prop.Util where
import Prop                      (Prop)
import Control.DeepSeq           (($!!), NFData)
import Control.Monad.Random      (Rand, RandT, StdGen)
import Control.Monad.State.Strict       (State)
import Data.Function             (on)
import System.CPUTime            (getCPUTime)
import System.Timeout            (timeout)
import Data.Set                  (Set)
import qualified Data.Set as Set (insert, singleton)
import Data.List(foldl')

type RandState a        = RandT StdGen (State Int) a
type RandM              = Rand StdGen
type RandProp           = RandM Prop

doubleton               :: Ord a => a -> a -> Set a
doubleton x y           = Set.insert x (Set.singleton y)

infinity                :: Double
infinity                = 1 / 0

roulette                :: Double -> [(Double, a)] -> a
roulette _ [(_,x)]      = x
roulette r ((d,a):rs)   = if r < d then a else roulette (r - d) rs

average                 :: [Double] -> Double
average xs              = foldl' pl 0 xs / fromIntegral (length xs)
    where pl x y        = if isInfinity y then x else x + y

isInfinity x = x == infinity || x == -infinity

timeOut :: NFData a => Double -> IO a -> IO (Double, Maybe a)
timeOut seconds m = do
    let n = round $ seconds * (10^6)
        io = do
            t0 <- getCPUTime
            !r  <- m
            tF <- getCPUTime
            return $!! (fromIntegral (tF - t0) / (10^12), r)
    !p' <- timeout n io
    return $ case p' of
         Just (d, !p) -> (d, Just p)
         Nothing     -> (seconds, Nothing)

timeOutPure :: NFData a => Double -> a -> IO (Double, Maybe a)
timeOutPure seconds f = timeOut seconds (return $!! f)

(.:) = (.) . (.)
(.:.) = (.) . (.:)
