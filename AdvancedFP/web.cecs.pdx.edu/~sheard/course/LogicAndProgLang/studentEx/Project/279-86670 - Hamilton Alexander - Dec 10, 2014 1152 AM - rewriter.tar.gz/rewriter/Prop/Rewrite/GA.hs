module Prop.Rewrite.GA where
import Prop          (Prop)
import Prop.Rewrite  (Rewrite)
import Prop.Util     (RandM)

data GeneticRewrite = GARW {
    
    fitnessFn       :: FitnessFn,
    selectionFn     :: SelectionFn,
    mutationFn      :: MutationFn,
    crossoverFn     :: CrossoverFn
}

-- A Fitness Function measures the performance of a rewrite on a single proposition,
--   by inspecting the original and rewritten proposition,
--   and considering the time measured for the rewrite. 
--   FitnessFn     :: time   -> p    -> p'   -> score
type FitnessFn      = Double -> Prop -> Prop -> Double

-- A Selection Function converts a list of fitness scored rewrites into
--   a distribution of rewrites to sample for the next generation.
--   SelectionFn   :: score  -> probability of duplication
type SelectionFn    = [(Double, Rewrite)] -> [(Double, Rewrite)]

-- A Mutation Function randomly alters a rewrite, parametrized by p, a stand-in for probability. 
-- Amount of mutation should increase monotonically as p increases.
--   MutationFn    :: p      -> rw      -> mutated rw
type MutationFn     = Double -> Rewrite -> RandM Rewrite

-- A Crossover Function randomly combines 2 rewrites, parametrized by p (see above).
--   CrossoverFn   :: p      -> parent 1 -> parent 2 -> child rw 
type CrossoverFn    = Double -> Rewrite -> Rewrite -> RandM Rewrite


data GAInstance = GAParams { 
    maxRewriteTime :: Double,
    crossoverRate :: Double,
    mutationRate :: Double,
    propConnectiveDist :: [Double],
    propVarRange :: (Int, Int),
    propSizeRange :: (Int, Int)
}
