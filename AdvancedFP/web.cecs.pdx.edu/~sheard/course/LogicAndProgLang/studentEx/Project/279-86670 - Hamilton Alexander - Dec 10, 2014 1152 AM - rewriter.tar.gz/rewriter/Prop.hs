{-# Language DeriveGeneric #-}

module Prop where
import Control.DeepSeq  (NFData(rnf))
import Control.DeepSeq.Generics (genericRnf)
import GHC.Generics     (Generic)

data Prop = Top
          | Bottom
          | Letter  !Int
          | Not     !Prop
          | And !Prop !Prop
          | Or !Prop !Prop
          | Implies !Prop !Prop
          deriving (Eq, Generic, Ord, Show)

infixr 3 `And`
infixr 2 `Or`
infixr 1 `Implies`


instance NFData Prop where rnf = genericRnf
