module Main where
import Prop.Gen
import Prop.Print
import Prop.Eval
import System.Environment

gen rs vars size verbose = do 
    p <- genProp' rs vars size
    putStrLn $ printProp p
    if not verbose then return () else do
        printStats p        

printStats p = let (taut, absurd) = satInfo p in do
    putStrLn $ "Size:   " ++ show (propSize p)
    putStrLn $ "Vars:   " ++ show (varCount p)
    putStrLn $ "Taut?   " ++ show taut
    putStrLn $ "Sat?    " ++ show (not absurd)
    putStrLn $ "Absurd? " ++ show absurd

main = do
    args <- getArgs
    if length args < 6 then printUsageString else do
    let rNot = (read (args !! 0) :: Double)
        rAnd = (read (args !! 1) :: Double)
        rOr  = (read (args !! 2) :: Double)
        rImp = (read (args !! 3) :: Double)
        vars = (read (args !! 4) :: Int)
        size = (read (args !! 5) :: Int)
        verbose = length args >= 7 && args !! 6 == "-v"
    gen [rNot, rAnd, rOr, rImp] vars size verbose

printUsageString = do
    prog <- getProgName
    putStrLn $ "Usage: " ++ prog ++ " <not> <and> <or> <implies> <vars> <size> [-v]"
    
