{-# Language FlexibleInstances, TypeSynonymInstances #-}
module Prop.Rewrite.GA.Fitness where
import Prop.Rewrite.GA (FitnessFn)
import Prop.Eval     (varCount, propSize, equal)
import Prop.Util     ((.:.), (.:), average, infinity)
import Data.Function (on)

-- Wrapper to make sure no erroneous rewrites are done
safeFitness          :: FitnessFn -> FitnessFn
safeFitness f        = \t p r -> if equal p r 
                        then f t p r
                        else error $ unwords 
                                   ["Rewritten proposition ",
                                    show r,
                                    " does not match original ",
                                    show p, "."] 

safeishFitness       :: FitnessFn -> FitnessFn
safeishFitness f     = \t p r -> if equal p r then f t p r else -infinity 

constFitness         :: Double -> FitnessFn
constFitness d _ _ _ = d


listFitness          :: ([Double] -> Double) -> [FitnessFn] -> FitnessFn
listFitness f fs     = \t p r -> f $ map (\f -> f t p r) fs

sizeResultOnly       :: FitnessFn
sizeResultOnly _ _   = fromIntegral . propSize

-- Measure only the original (not the rewritten) proposition.
-- This could be used to select for rewrite rules that can _finish at all_ on large propositions.
sizeOriginalOnly     :: FitnessFn
sizeOriginalOnly _ p _ = fromIntegral $ propSize p

-- Measurements comparing the original proposition to the result
-- sizeDifference: size of original - size of result
sizeDifference       :: FitnessFn
sizeDifference _     = (-) `on` fromIntegral . propSize

-- varsDifference :: var count of original - var count of result
varsDifference       :: FitnessFn
varsDifference _     = (-) `on` fromIntegral . varCount

varsRatio            :: FitnessFn
varsRatio _          = (/) `on` fromIntegral . varCount

sizeRatio            :: FitnessFn
sizeRatio _          = (/) `on` fromIntegral . propSize

-- Measurements solely considering time
time                 :: FitnessFn
time t _ _           = t

timeCap              :: Double -> FitnessFn
timeCap max t _ _    = if t >= max then -infinity else 0

timeRatio            :: Double -> FitnessFn
timeRatio max t _ _  = t / max

-- A simple composite measurement
timeAndSize          :: Double -> FitnessFn
timeAndSize max t p q = negate (timeRatio max t p q + sizeRatio t p q)

{- This instance currently seems to have some infinite loops 

lift2Fitness         :: (Double -> Double -> Double) -> FitnessFn -> FitnessFn -> FitnessFn
lift2Fitness op a b  = \t p r -> a t p r `op` b t p r

-- Num instance for convenient notation
instance Num FitnessFn where
    (+) = lift2Fitness (+)
    (*) = lift2Fitness (*)
    abs = (abs .:.)
    signum = (signum .:.)
    fromInteger = constFitness . fromInteger

instance Fractional FitnessFn where
    (/) = lift2Fitness (/)
    fromRational = constFitness . fromRational

instance Floating FitnessFn where
    log = (log .:.)
    exp = (exp .:.)
    sin = (sin .:.)
    cos = (cos .:.)
    tan = (tan .:.)
    asin = (asin .:.)
    acos = (acos .:.)
    atan = (atan .:.)
    sinh = (sinh .:.)
    cosh = (cosh .:.)
    tanh = (tanh .:.)
    asinh = (asinh .:.)
    acosh = (acosh .:.)
    atanh = (atanh .:.)
    pi   = constFitness pi 

-- More complicated composites

-- Arithmetic composites
sizeTimeRatio        = sizeRatio / time
sizeTimeLogDiff      = log sizeRatio - log time
sizeVarsTime         = sizeRatio * varsRatio / time
sizeVarsTimeLog      = log sizeRatio + log varsRatio - log time

-}


-- Higher order composites of many fitness functions
worstFitness         = listFitness minimum
averageFitness       = listFitness average
bestFitness          = listFitness maximum
sumFitness           = listFitness sum
productFitness       = listFitness product
sumLogFitness        = listFitness (sum . map log)


