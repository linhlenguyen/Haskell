module Main where
import Prop.Gen
import Prop.Print
import Prop.Eval
import Prop.Util
import System.Environment
import Control.Monad

gen rs vars size trials = do 
    ps <- replicateM trials $ genProp' rs vars size
    printStats ps        

printStats ps = do
    let ss = map satInfo ps
        b True = 1.0
        b False = 0.0
        avg = average
        fi = fromIntegral
        psl x = putStrLn $ "Average " ++ x
    psl $ "Size:   " ++ show (avg $ map (fi . propSize) ps)
    psl $ "Vars:   " ++ show (avg $ map (fi . varCount) ps)
    psl $ "Taut?   " ++ show (avg $ map (b . fst) ss)
    psl $ "Sat?    " ++ show (avg $ map (b . not . snd) ss)
    psl $ "Absurd? " ++ show (avg $ map (b . snd) ss)

main = do
    args <- getArgs
    if length args < 6 then printUsageString else do
    let rNot = (read (args !! 0) :: Double)
        rAnd = (read (args !! 1) :: Double)
        rOr  = (read (args !! 2) :: Double)
        rImp = (read (args !! 3) :: Double)
        vars = (read (args !! 4) :: Int)
        size = (read (args !! 5) :: Int)
        trials = (read (args !! 6) :: Int)
    gen [rNot, rAnd, rOr, rImp] vars size trials

printUsageString = do
    prog <- getProgName
    putStrLn $ "Usage: " ++ prog ++ " <not> <and> <or> <implies> <vars> <size> <trials> [-v]"
    
