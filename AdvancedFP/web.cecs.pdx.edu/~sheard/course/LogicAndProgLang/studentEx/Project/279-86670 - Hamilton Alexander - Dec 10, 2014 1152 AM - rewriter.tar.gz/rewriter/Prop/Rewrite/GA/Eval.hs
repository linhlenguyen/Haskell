{-# Language BangPatterns #-}

module Prop.Rewrite.GA.Eval where

import Prop
import Prop.Rewrite
import Prop.Rewrite.GA
import Prop.Rewrite.Eval
import Prop.Gen
import Control.Monad.Random
import Control.Monad
import Prop.Util
import Control.DeepSeq


-- One round of GA
evalGA1 ::  GeneticRewrite -> GAInstance -> [Rewrite] -> IO [Rewrite]
evalGA1 fns args rws = do
    let l = length rws
    putStrLn "Generating proposition..."
    p <- genPropUpTo (propConnectiveDist args) (propVarRange args) (propSizeRange args)
    
    putStrLn "Evaluating fitness..."
    scores <- performFitnessScore (fitnessFn fns) (maxRewriteTime args) p rws  
    putStrLn $ "Average fitness: " ++ show (average scores)

    putStrLn "Selecting parents..."
    parents <- performSelection l (selectionFn fns) (zip scores rws)
    
    putStrLn "Applying mutations..."
    mutants <- performMutation (mutationFn fns) (mutationRate args) parents
    
    putStrLn "Applying crossover..."
    performCrossover l (crossoverFn fns) (crossoverRate args) mutants

evalGA :: GeneticRewrite -> GAInstance -> Int -> [Rewrite] -> IO [Rewrite]
evalGA _ _ i rws | i <= 0 = return rws
evalGA fns args i rws = putStrLn ("Generations remaining: " ++ show i) >> 
                        evalGA1 fns args rws >>= evalGA fns args (i - 1)

genPropUpTo dist vs s = do
    vars <- evalRandIO $ getRandomR vs
    size <- evalRandIO $ getRandomR s
    genProp' dist vars size

performFitnessScore fn t p rws = mapM e rws
  where f (t,(Just q)) = fn t p q
        f (t, Nothing)  = -infinity
        e rw = fmap f $ evalTimeOut t rw p
         
performSelection l fn candidates = do
    let selection = force $ fn candidates
    samples <- replicateM l $ evalRandIO (getRandomR (0, sum (map fst selection)))
    let parents =force $ map (\r -> roulette r selection) samples
    return parents

performMutation !fn !rate !parents = evalRandIO $ mapM (fn rate) parents

performCrossover l fn rate parents = return parents
