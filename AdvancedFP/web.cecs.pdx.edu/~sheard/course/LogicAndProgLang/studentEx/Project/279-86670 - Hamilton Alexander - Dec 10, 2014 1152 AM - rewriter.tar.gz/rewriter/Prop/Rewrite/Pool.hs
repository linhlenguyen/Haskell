module Prop.Rewrite.Pool where

import Prop.Rewrite(RewritePool(..))
import Prop.Eval(equal, equal', propSize, varCount, assignCount)
import Prop.Rewrite.Algo
import Prop.Rewrite.Prim
import Prop.Rewrite.EqPred
import Data.Function(on)

emptyPool :: RewritePool
emptyPool = RewritePool [] [] [] [] [] [] [] []

fullPool :: RewritePool
fullPool = emptyPool { 
    primFns = [
        (shrinkIdentities, "simple shrinking identities"),
        (idOr, "simple identities of Or"),
        (idImplies, "simple identities of Implies"),
        (idNot, "simple identities of Not"),
        (idAnd, "simple identities of And"),
        (elimTautology, "identification of semantic Top or Bottom"),
        (deMorganPush, "push Not deeper with deMorgan involution"),
        (deMorganPull, "pull Not higher with deMorgan involution"),
        (elimImplies, "push Imply identities deeper"),
        (nnf, "negation normal form"),
        (distribute, "distribute And/Or with each other and Implies with itself"),
        (doubleDistribute, "double distributivity"),
        (assocLeft, "left associativity of And/Or"),
        (assocRight, "right associativity of And/Or"),
        (commute, "commutivity of And/Or/Implies"),
        (transpose, "transposition of Implies"),
        (materialize, "Implies to material implication"),
        (dematerialize, "material implication to Implies"),
        (exportation, "exportation of Implies"),
        (importation, "importation of Implies"),
        (implicationTaut, "identification of tautological Implies"),
        (elimSimple, "non-recursive structural equality")

    ],

    predFns = [
    ],

    sizeFns = [
        (propSize, "proposition size"),
        (varCount, "variable count"),
        (assignCount, "number of possible assignments")
    ],

    eqFns = [
        (equal,  "bidirectional implication"),
        (equal', "identical truth tables with union of vars"),
        ((==),   "structural equality")
    ],

    eqPredFns = [
        (introNegate, "Not from contradicting Implies"),
        (elimConjugate, "elimination of conjugate pair"),
        (elimRedundant, "elimination of duplicate clauses"),
        (unDistribute, "collapsing distributed And/Or and Implies"),
        (doubleUnDistribute, "collapsing double distributed And/Or")
    ],

    convergePredFns = [
        ((==) `on` propSize, "size is unchanged"),
        ((==) `on` varCount, "number of variables is unchanged"),
        ((<=) `on` propSize,  "size is increased by change")
    ] ++ eqFns fullPool,

    algoFns = [
        (bottomUp, "bottom-up"),
        (topDown,   "top-down")
        --(pickLargestSubtree,"to largest subtree"),
        --(pickSmallestSubtree, "to smallest subtree"),
        --(pickLeastVars, "to subtree with least vars"),
        --(pickMostVars, "to subtree with most vars"),
        --(findLargestComponent, "top-down along largest subtrees"),
        --(findMostVarComponent, "top-down along subtrees with most vars")
    ],

    seedRewrites = [

    ]
    
}
