import Prop.Rewrite.Gen
import Prop.Rewrite.Pool
import Prop.Rewrite.Print
import System.Environment

main = do
    as <- getArgs
    if length as < 1 then printUsageString else do
        let size = read (head as) :: Int
        rw <- genRewrite' size fullPool
        putStrLn (show rw)

printUsageString = do
    prog <- getProgName
    putStrLn $ "Usage: " ++ prog ++ " <size>"
    
