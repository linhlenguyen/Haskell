
-- Generate a random prop and rewrite and try to simplify
-- This will probably fail.
-- I swear I had it working at some point,
-- but one of the things I changed to make the genetic algorithm
-- vaguely work better (but still not work) must have broken it...
-- Anyway. If the underlying algorithms worked, here's a program
-- that would use them.

module Main where
import Prop.Gen
import Prop.Print
import Prop.Eval
import Prop.Rewrite.Gen
import Prop.Rewrite.Pool
import Prop.Rewrite.Eval
import Prop.Rewrite.Print
import System.Environment
import Prop.Rewrite.Composite

gen rs vars size rw_size = do 
    p <- genProp' rs vars size
    rw <- return genRewrite' rw_size fullPool
    putStrLn $ show rw
    let p' = evalCompletely rw p
    printStats p p'        

printStats p q = do
    putStrLn $ "Size(p):   " ++ show (propSize p)
    putStrLn $ "Vars(p):   " ++ show (varCount p)
    putStrLn $ "Size(p'):  " ++ show (propSize q)
    putStrLn $ "Vars(p'):  " ++ show (varCount q)
    putStrLn $ "Equal?     " ++ show (equal p q)

main = do
    args <- getArgs
    if length args < 6 then printUsageString else do
    let rNot = (read (args !! 0) :: Double)
        rAnd = (read (args !! 1) :: Double)
        rOr  = (read (args !! 2) :: Double)
        rImp = (read (args !! 3) :: Double)
        vars = (read (args !! 4) :: Int)
        size = (read (args !! 5) :: Int)
        rw_size = (read (args !! 6) :: Int)
    gen [rNot, rAnd, rOr, rImp] vars size rw_size

printUsageString = do
    prog <- getProgName
    putStrLn $ "Usage: " ++ prog ++ " <not> <and> <or> <implies> <vars> <size> <rewrite size>"
    
