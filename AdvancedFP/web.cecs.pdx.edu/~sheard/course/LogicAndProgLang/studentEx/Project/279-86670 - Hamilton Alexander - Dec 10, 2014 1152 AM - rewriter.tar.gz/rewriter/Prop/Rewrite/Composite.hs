module Prop.Rewrite.Composite where

import Prop.Discrim         (simpleCnf)
import Prop.Rewrite         (Rewrite(..))
import Prop.Rewrite.Prim    (shrinkIdentities, deMorganPush, nnf)
import Prop.Rewrite.Algo    (topDown, bottomUp)
import Prop.Rewrite.EqPred  (elimRedundant, unDistribute)

-- Composite rewrites
simplifierTedCooper :: Rewrite
simplifierTedCooper = Converge (==) 10
                    (Sequence [Algo topDown (Sequence [Prim shrinkIdentities "shrinking identities",
                                                        EqPred (==) elimRedundant "structural equality" "eliminate duplicate clauses",
                                                        Prim deMorganPush "push deMorgan involution"]) "applied top down",
                                Prim simpleCnf "simplify via CNF"]) "structural equality"

simplifierKendallStewart :: Rewrite
simplifierKendallStewart = Sequence [Algo topDown  (EqPred (==) unDistribute "structural equality" "factor") "applied top down",
                                     Algo bottomUp (Prim shrinkIdentities "shrinking identities") "applied bottom up",
                                     Prim simpleCnf "simplify via CNF"]
