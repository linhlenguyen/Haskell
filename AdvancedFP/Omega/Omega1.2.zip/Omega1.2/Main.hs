-- Copyright (c) Tim Sheard
-- OGI School of Science & Engineering, Oregon Health & Science University
-- Maseeh College of Engineering, Portland State University
-- Subject to conditions of distribution and use; see LICENSE.txt for details.
-- Mon Nov  7 10:25:59 Pacific Standard Time 2005
-- Omega Interpreter: version 1.2

module Main where

import qualified Toplevel as T

main = T.omega
