-- Copyright (c) 2002-2010, Tim Sheard
-- OGI School of Science & Engineering, Oregon Health & Science University
-- Maseeh College of Engineering, Portland State University
-- Subject to conditions of distribution and use; see LICENSE.txt for details.
-- Wed Apr 14 13:36:19 Pacific Daylight Time 2010
-- Omega Interpreter: version 1.4.5

module Version where
version = "Omega Interpreter: version 1.4.5"
buildtime = "Wed Apr 14 13:36:19 Pacific Daylight Time 2010"
