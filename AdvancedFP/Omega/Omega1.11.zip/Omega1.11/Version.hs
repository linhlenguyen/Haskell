-- Copyright (c) Tim Sheard
-- OGI School of Science & Engineering, Oregon Health & Science University
-- Maseeh College of Engineering, Portland State University
-- Subject to conditions of distribution and use; see LICENSE.txt for details.
-- Thu Jun 23 11:51:26 Pacific Daylight Time 2005
-- Omega Interpreter: version 1.1 (revision 1)

module Version where
version = "Omega Interpreter: version 1.1 (revision 1)"
buildtime = "Thu Jun 23 11:51:26 Pacific Daylight Time 2005"
