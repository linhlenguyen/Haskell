-- Copyright (c) Tim Sheard
-- OGI School of Science & Engineering, Oregon Health & Science University
-- Maseeh College of Engineering, Portland State University
-- Subject to conditions of distribution and use; see LICENSE.txt for details.
-- Sun Mar 28 16:05:41 Pacific Daylight Time 2010
-- Omega Interpreter: version 1.4.4

module Version where
version = "Omega Interpreter: version 1.4.4"
buildtime = "Sun Mar 28 16:05:41 Pacific Daylight Time 2010"
