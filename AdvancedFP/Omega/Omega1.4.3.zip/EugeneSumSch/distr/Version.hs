-- Copyright (c) Tim Sheard
-- OGI School of Science & Engineering, Oregon Health & Science University
-- Maseeh College of Engineering, Portland State University
-- Subject to conditions of distribution and use; see LICENSE.txt for details.
-- Sat Jul 26 08:58:26 Pacific Daylight Time 2008
-- Omega Interpreter: version 1.4.3

module Version where
version = "Omega Interpreter: version 1.4.3"
buildtime = "Sat Jul 26 08:58:26 Pacific Daylight Time 2008"
