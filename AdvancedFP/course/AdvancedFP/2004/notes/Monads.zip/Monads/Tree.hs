module Tree where

data T a = Empty | Single a | Node (Tree.T a) (Tree.T a)

empty = Empty
leaf  = Single
fork  = Node


merge Empty t = t
merge t Empty = t
merge t1 t2 = Node t1 t2

fold :: b -> (a -> b) -> (b -> b -> b) -> Tree.T a -> b
fold e s j Empty = e
fold e s j (Single a) = s a
fold e s j (x `Node` y) = fold e s j x `j` fold e s j y

toList :: Tree.T a -> [a] 
toList x = fold id (:) (.) x []


instance Functor Tree.T where
    fmap f Empty        = Empty
    fmap f (Single a)   = Single (f a)
    fmap f (x `Node` y)   = fmap f x `Node` fmap f y


instance Monad Tree.T where
    return = Single
    Empty >>= f    = Empty
    Single a >>= f = f a
    (x `Node` y) >>= f  = (x >>= f) `Node` (y >>= f) 
    
        

