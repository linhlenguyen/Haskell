module Monadic(module Monadic, module Monad) where

import Monad

infixl 1 #, <#

( # )           :: Monad m => (a -> b) -> (m a -> m b)
( # )           = liftM

(<#)          :: Monad m => m (a -> b) -> m a -> m b
(<#)          = ap


whenM         :: Monad m => m Bool -> m () -> m ()
whenM p m     = do b <- p; when b m

unlessM       :: Monad m => m Bool -> m () -> m ()
unlessM p m   = whenM (notM p) m

notM          :: Monad m => m Bool -> m Bool
notM p        = liftM not p

whileM        :: Monad m => m Bool -> m () -> m ()
whileM p m    = whenM p (m >> whileM p m)

untilM        :: Monad m => m () -> m Bool -> m ()
m `untilM` p  = m >> unlessM p (m `untilM` p)


allM p []     = return True
allM p (x:xs) = do b <- p x
                   if b then allM p xs else return False

anyM p []     = return False
anyM p (x:xs) = do b <- p x
                   if b then return True else anyM p xs 
                  




