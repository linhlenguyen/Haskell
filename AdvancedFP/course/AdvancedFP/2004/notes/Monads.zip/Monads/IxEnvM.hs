module IxEnvM (HasEnv(..), EnvM, withEnv) where

import MT
import MonadRec


type EnvM e = (->) e 

withEnv :: e -> EnvM e a -> a
withEnv e f = f e

mapEnv :: (e2 -> e1) -> EnvM e1 a -> EnvM e2 a
mapEnv f = (.f)

instance Functor ((->) e) where
    fmap    = (.)

instance Monad ((->) e) where
    return  = const
    f >>= g = \e -> g (f e) e
    f >> g  = g

instance HasEnv ((->) e) Z e where
    getEnv _        = id
    inModEnv _ f g  = g . f
    inEnv _ e f     = \e' -> f e

instance MonadRec ((->) e) where
    mfix f e = let a = f a e in a

